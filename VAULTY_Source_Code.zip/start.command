#!/bin/bash
cd "$(dirname "$0")"

# Ensure local node binary is available in PATH
export PATH="$(pwd)/.tools/node/bin:$PATH"

echo "=================================================="
echo "⚡ Starting Vaulty (SubTrack) - BCA Minor Project"
echo "Candidate: Lakshya Singh | Roll: 240919106122"
echo "College: IMS Noida (CCSU) | Subject: BCA-508"
echo "=================================================="
echo "Starting local server and opening http://localhost:3000..."

# Open browser automatically after 2 seconds
(sleep 2 && open "http://localhost:3000") &

# Start dev server
npm run dev
